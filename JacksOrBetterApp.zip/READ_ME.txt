*Welcome to Jacks or Better Rules*

Note: All input regarding bets, money, and winnings are expected to be integers. If you input a character or string, the program will not work.
      However, there are restrictions on the integers you input. The program will tell you what to do, and after inputting any value you must hit enter
      for the application to move to the next step. 

Rules: Disclaimer - Knowing what each hand in poker is will help you determine how to select cards to remove.

1. In order to make money back that you betted, you must have at least a pair in your hand that is a jack or better. For example, a pair or queens, kings, or aces
   will result in you getting back the money betted on a hand. 
2. The cards a labeled as "S3," "C5," "DJ," "HA," etc. The first character represents the suit of the card, so:
   S = spade, C = club, D = diamond, and H = heart. The character represents the value, so:
   J = jack, Q = queen, K = king, and A = ace. The numbers range from 2-10 like any card deck. 
3. How much you earn from each bet depending on the hand you receive will be showcased before you make your bets in a table. 
4. Once you receive your first hand (a hand is 5 cards), you can pick how many cards you wish to replace. Remember, you need a Jacks or Better pair at least to make
   you bet back. Of course, you no not need a jack or better pair to make money. You can have a straight or a flush as well.
5. Once you decide how many cards you wish to replace, you will be prompted to select the cards you will get rid of. You can only input one number for each prompt. 
   This should be clear once you're in the game.
6. Once you receive your final hand, a message will pop up telling you what your hand is and how much money you have.
7. You can play as many rounds as you wish. If you run out of money, you will no longer be able to make bets greater than 0.
